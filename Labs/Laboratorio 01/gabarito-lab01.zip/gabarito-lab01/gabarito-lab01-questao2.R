# Reusando execução do script da questão 1
source('gabarito-lab01-questao1.R')
dados = read.table('resultado-lab01-questao1.txt', header=TRUE)

media.regiao = with(dados, aggregate(Salario.Bruto, list(Regiao), mean))
colnames(media.regiao) = c("Regiao", "Media.Salarial")

media.regiao = media.regiao[order(media.regiao$Media.Salarial, decreasing=TRUE),]

write.table(media.regiao, file="resultado-lab01-questao2.txt", row.names=F)
