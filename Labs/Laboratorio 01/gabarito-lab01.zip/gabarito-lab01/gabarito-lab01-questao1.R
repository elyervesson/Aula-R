dados = read.csv('salarios-ti-formatted.csv')

regiao.ne = c("MA","PI","CE","RN","PB","PE","AL","SE","BA")
regiao.co = c("DF","GO","MS","MT")
regiao.sd = c("RJ","SP","MG","ES")
regiao.s  = c("RS","SC","PR")
regiao.n  = c("PA","AC","AM","RR","RO","TO","AP")

dados$Regiao = NA

dados[is.element(dados$UF, regiao.ne),]$Regiao = "Nordeste"
dados[is.element(dados$UF, regiao.co),]$Regiao = "Centro-oeste"
dados[is.element(dados$UF, regiao.sd),]$Regiao = "Sudeste"
dados[is.element(dados$UF, regiao.s),]$Regiao  = "Sul"
dados[is.element(dados$UF, regiao.n),]$Regiao  = "Norte"

write.table(dados, file="resultado-lab01-questao1.txt", row.names=F)
