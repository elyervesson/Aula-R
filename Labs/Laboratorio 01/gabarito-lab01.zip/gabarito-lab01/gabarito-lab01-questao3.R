dados = read.csv('salarios-ti-formatted.csv')

privada = subset(dados, Iniciativa.Privada.ou.Concursado == "Iniciativa Privada")
exp.media.privada = mean(privada$Experiencia.Profissional) 

write.table(exp.media.privada, file="resultado-lab01-questao3.txt", row.names=F, col.names=F)
